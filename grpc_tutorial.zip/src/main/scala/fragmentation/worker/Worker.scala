package fragmentation.worker

import fragmentation.Fragmentation.{FragServiceGrpc,SendRequest,SendReply}
import fragmentation.Fragmentation.FragServiceGrpc.FragServiceBlockingStub
import org.apache.logging.log4j.scala.Logging
import io.grpc.{ManagedChannel, ManagedChannelBuilder, StatusRuntimeException}
import fragmentation.common.Util.getMyIpAddress
import java.util.concurrent.TimeUnit


object Worker {
  def apply(host: String, port: Int): Worker = {
    val channel = ManagedChannelBuilder.forAddress(host, port).usePlaintext().asInstanceOf[ManagedChannelBuilder[_]].build
    val blockingStub = FragServiceGrpc.blockingStub(channel)
    new Worker(channel, blockingStub)
  }

  def main(args: Array[String]): Unit = {
    val masterEndpoint = args.headOption
    if (masterEndpoint.isEmpty)
      System.out.println("Master ip:port argument is empty.")
    else {
      val splitedEndpoint = masterEndpoint.get.split(':')
      val client = Worker(splitedEndpoint(0), splitedEndpoint(1).toInt)
      try {
        client.SendMessage()
      } finally {
        client.shutdown()
      }
    }
  }
}

class Worker private(
                      private val channel: ManagedChannel,
                      private val blockingStub: FragServiceBlockingStub
                    ) extends Logging {

  def shutdown(): Unit = {
    channel.shutdown.awaitTermination(5, TimeUnit.SECONDS)
  }

  def SendMessage(): Unit = {
    val request = SendRequest(requestMessage = getMyIpAddress)
    try {
      val response = blockingStub.sendMessage(request)
      logger.info("SendMessage: " + response.replyMessage)
    }
    catch {
      case e: StatusRuntimeException =>
        logger.warn(s"RPC failed: ${e.getStatus}")
    }
  }
}